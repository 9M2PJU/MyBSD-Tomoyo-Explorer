/* -*- c-file-style: "ruby" -*- */
/************************************************

  rbgdkimlib.h -

  $Author: klamath $
  $Date: 2001/10/04 02:13:46 $

  Copyright (C) 1999-2000 NAKAMURA Hideki,
                          Hiroshi Igarashi
************************************************/

extern VALUE mImlib;
extern VALUE cImlibImage;
extern VALUE cImlibBorder;
extern VALUE cImlibShape;
extern VALUE cImlibModifier;
extern VALUE cImlibSaveInfo;

