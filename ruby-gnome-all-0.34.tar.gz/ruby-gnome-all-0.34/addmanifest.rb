STDOUT.print("\
MANIFEST
ChangeLog
README
extconf.rb
")
ARGV.each do |subdir|
  manifest_path = subdir + File::Separator + "MANIFEST"
  if File.file?(manifest_path)
    File.open(manifest_path) do |manifest|
      manifest.each_line do |line|
	STDOUT.puts(subdir + File::Separator + line)
      end
    end
  end
end
