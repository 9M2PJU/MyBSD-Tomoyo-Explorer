/* -*- c-file-style: "ruby" -*- */
/**********************************************************************

  rbart.h - header file for Art module of ruby

  $Author: mutoh $
  $Date: 2003/07/03 16:29:05 $

  Copyright (C) 2002  KUBO Takehiro <kubo@jiubao.org>

**********************************************************************/

#ifndef _RBART_H_included
#define _RBART_H_included
#include <libart_lgpl/libart.h>
#include <ruby.h>

#ifndef ULONG2NUM
#define ULONG2NUM UINT2NUM
#endif

extern VALUE mArt;
extern VALUE artAffine;
extern VALUE artSVP;
extern VALUE artBpath;
extern VALUE artVpath;
extern VALUE artVpathDash;
extern VALUE artCanvas;

double *get_art_affine(VALUE);
VALUE make_art_affine(double[6]);

void Init_art_affine();

ArtSVP *get_art_svp(VALUE);
VALUE make_art_svp(ArtSVP *);

void Init_art_svp();

ArtBpath *get_art_bpath(VALUE);
VALUE make_art_bpath(ArtBpath *);

void Init_art_bpath();

ArtVpath *get_art_vpath(VALUE);
VALUE make_art_vpath(ArtVpath *);

ArtVpathDash *get_art_vpath_dash(VALUE);
VALUE make_art_vpath_dash(ArtVpathDash *);

void Init_art_vpath();

void Init_art_canvas();

#endif /* ! _RBART_H_included */
