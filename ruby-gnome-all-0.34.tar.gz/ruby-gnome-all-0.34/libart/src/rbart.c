/* -*- c-file-style: "ruby" -*- */
/**********************************************************************

  rbart.c -

  $Author: mutoh $
  $Date: 2003/01/04 05:35:01 $

  Copyright (C) 2002  KUBO Takehiro <kubo@jiubao.org>

**********************************************************************/

#include "rbart.h"

VALUE mArt;

void
Init_libart()
{
	mArt = rb_define_module("Art");

	Init_art_affine();
	Init_art_bpath();
	Init_art_canvas();
	Init_art_svp();
	Init_art_vpath();
}
